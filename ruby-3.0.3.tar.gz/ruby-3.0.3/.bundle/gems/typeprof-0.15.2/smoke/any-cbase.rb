class Unknown::Foo
end

__END__
# Classes
